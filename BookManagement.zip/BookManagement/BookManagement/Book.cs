﻿namespace BookManagement
{
    public enum Genre
    {
        Fiction, NonFiction, Mystery, Romance, ScienceFiction
    }
    public class Book
    {
        public string Title { get; set; }
        public Author Author { get; set; }
        public Genre BookGenre { get; set; }

        public Book(string title, Author author, Genre genre)
        {
            Title = title;
            Author = author;
            BookGenre = genre;
        }
    }
}