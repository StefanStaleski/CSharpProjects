﻿namespace BookManagement
{
    class Program : BookManagementMethods
    {
        static void Main(string[] args)
        {
            var books = new List<Book>
        {
            new Book("Book1", new Author { FirstName = "John", LastName = "Doe" }, Genre.Fiction),
            new Book("Book2", new Author { FirstName = "Jane", LastName = "Doe" }, Genre.Romance),
            new Book("Book3", new Author { FirstName = "James", LastName = "Smith" }, Genre.Mystery),
            new Book("Book4", new Author { FirstName = "Emma", LastName = "Johnson" }, Genre.ScienceFiction),
            new Book("Book5", new Author { FirstName = "Michael", LastName = "Brown" }, Genre.NonFiction)
        };

            Console.WriteLine("Would you like to get the books based on a specific Genre? Type 'Yes' or 'No'.");
            var userGenreChoice = Console.ReadLine();
            Console.WriteLine("Would you like to get the books based on a specific Author? Type 'Yes' or 'No'.");
            var userAuthorChoice = Console.ReadLine();
            if (userGenreChoice.ToLower() == "yes")
            {
                Console.WriteLine("By which specific genre would you like them based? Type 'Fiction', 'NonFiction', 'Mystery', 'Romance', 'ScienceFiction'");
                userGenreChoice = Console.ReadLine().Trim().ToLower();
                switch (userGenreChoice)
                {
                    case "fiction":
                        DisplayBooksBySpecificGenre(books, Genre.Fiction);
                        break;
                    case "nonfiction":
                        DisplayBooksBySpecificGenre(books, Genre.NonFiction);
                        break;
                    case "mystery":
                        DisplayBooksBySpecificGenre(books, Genre.Mystery);
                        break;
                    case "romance":
                        DisplayBooksBySpecificGenre(books, Genre.Romance);
                        break;
                    case "sciencefiction":
                        DisplayBooksBySpecificGenre(books, Genre.ScienceFiction);
                        break;
                    default:
                        Console.WriteLine("You did not input a valid genre.");
                        break;
                }
            }
            if (userAuthorChoice == "yes")
            {
                Console.WriteLine("Write the first and/or last name of the author.");
                userAuthorChoice = Console.ReadLine().Trim().ToLower();
                DisplayBooksBySpecificAuthor(books, userAuthorChoice);

            }
            else
            {
                DisplayAllBooks(books);
            }
            DisplayCountOfBooksInEachGenre(books);
            DisplayCountOfBooksForEachAuthor(books);


        }
    }
}