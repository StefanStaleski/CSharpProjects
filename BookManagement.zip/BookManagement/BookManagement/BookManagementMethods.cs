﻿namespace BookManagement
{
    public class BookManagementMethods
    {

        public static void DisplayAllBooks(List<Book> books)
        {
            foreach (var book in books)
            {
                Console.Write($"{book.Title} ");
                Console.Write($"{book.Author.FirstName} ");
                Console.Write($"{book.Author.LastName} ");
                Console.WriteLine($"{book.BookGenre}");
            }
        }
        public static void DisplayBooksBySpecificAuthor(List<Book> books, string userInput)
        {
            var booksToDisplay = books.Where(b => b.Author.FirstName == userInput || b.Author.LastName == userInput).ToList();
            DisplayAllBooks(booksToDisplay);
        }
        public static void DisplayBooksBySpecificGenre(List<Book> books, Genre userInput)
        {
            var booksToDisplay = books.Where(b => b.BookGenre == userInput).ToList();
            DisplayAllBooks(booksToDisplay);
        }
        public static void DisplayCountOfBooksForEachAuthor(List<Book> books)
        {
            var booksCountByAuthor = books.GroupBy(b => b.Author.FirstName + " " + b.Author.LastName).Select(g => "Author: " + g.Key + ", Book Count: " + g.Count());
            foreach (var book in booksCountByAuthor)
            {
                Console.WriteLine(book);
            }
        }
        public static void DisplayCountOfBooksInEachGenre(List<Book> books)
        {
            var booksCountByGenre = books.GroupBy(b => b.BookGenre);
            foreach (var book in booksCountByGenre)
            {
                Console.WriteLine($"Number of {book.Key} books: {book.Count()}");
            }
        }
    }
}