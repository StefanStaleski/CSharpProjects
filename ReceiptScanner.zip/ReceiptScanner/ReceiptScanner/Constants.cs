﻿namespace ReceiptScanner
{
    public static class Constants
    {
        public const string ApiUrl = "https://interview-task-api.mca.dev/qr-scanner-codes/alpha-qr-gFpwhsQ8fkY1";
    }
}