﻿using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;

namespace ReceiptScanner
{
	class Program
	{
		public class ReceiptData // Class to get the data from the API Url
		{
            public string? Name { get; set; }
            public bool Domestic { get; set; }
            public float Price { get; set; }
            public int Weight { get; set; }
            public string? Description { get; set; }
        }

		static async Task Main(String[] args)
		{
			var receiptData = new List<ReceiptData>(); // List that will receive the API Url data

			var apiUrl = "https://interview-task-api.mca.dev/qr-scanner-codes/alpha-qr-gFpwhsQ8fkY1"; // API Url

			try
			{
				using(var httpClient = new HttpClient())
				{
					var response = await httpClient.GetAsync(apiUrl); // Send GET Request to get data from API Url

					if(response.IsSuccessStatusCode) // Check if data is successfully received from API url
					{
						JsonSerializerOptions options = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase }; // Assign naming policy to be camel case

						string jsonResponse = await response.Content.ReadAsStringAsync(); // Read the data from the API Url as a json string

						receiptData = JsonSerializer.Deserialize<List<ReceiptData>>(jsonResponse, options); // Deserialise the json string into a List of ReceiptData type

						var hasInvalidData = CheckInvalidData(receiptData); // Check if there is any invalid data inside the receiptData list

						if(hasInvalidData) // If there is invalid data, inform the user and stop the application
						{
							Console.WriteLine("Something is wrong with the API data, please check.");
							return;
						}

						receiptData = receiptData!.OrderBy(x => x.Name).ToList(); // Order Alphabetically

						var groupedReceiptData = receiptData.GroupBy(x => x.Domestic); // Group by Domestic or Imported


						foreach(var item in  groupedReceiptData) // Print Domestic and Imported values
						{
							Console.WriteLine($". {GetOriginType(item)}");

							foreach(var data in item)
							{
								PrintItemData(data);
							}
						}

						foreach(var item in groupedReceiptData) // Print total cost of each origin
						{
							var totalCost = item.Sum(x => x.Price).ToString("F1"); // Get sum of each origin, ToString("F1") means to make it with one decimal

							Console.WriteLine($"{GetOriginType(item)} cost: ${totalCost}");
						}

						foreach(var item in groupedReceiptData) // Print total count of each origin
						{
							var totalCount = item.Count(); // Get count of each origin

							Console.WriteLine($"{GetOriginType(item)} count: {totalCount}");
						}
					}
				}
			}

			catch(HttpRequestException ex)
			{
				Console.WriteLine($"An HTTP exception occured. Exception message: {ex.Message}");
			}

			catch (JsonException ex)
			{
				Console.WriteLine($"A JSON exception occured. Exception message: {ex.Message}");
			}

			catch(ArgumentNullException ex)
			{
				Console.WriteLine($"A Null Reference exception occured. Exception message; {ex.Message}");
			}

			catch(Exception ex)
			{
				Console.WriteLine(ex.Message);
			}
		}

		private static string GetWeight(int weight) // Returns the weight if greater than 0 or return N/A if weight is 0 or less
		{
			if(weight <= 0)
			{
				return "N/A";
			}

			return weight + "g";

		}

		private static bool CheckInvalidData(List<ReceiptData>? receiptData) // Checks for any invalid data inside the received data from the API Url
		{
            if (receiptData == null)
            {
				return true;                
            }

            return receiptData.Any(x => string.IsNullOrWhiteSpace(x.Name) || string.IsNullOrWhiteSpace(x.Description) || x.Price < 0);
		}

		private static string GetOriginType(IGrouping<bool, ReceiptData> item) // Returns the origin type depending on the Domestic value
		{
			return item.Key ? "Domestic" : "Imported";
		}

		private static void PrintItemData(ReceiptData data)
		{
			Console.WriteLine($"... {data.Name}");
			Console.WriteLine($"    Price: ${data.Price.ToString("F1")}");
			Console.WriteLine($"    {data.Description!.Substring(0, 10)}...");
			Console.WriteLine($"    Weight: {GetWeight(data.Weight)}");
		}
	}
}