﻿using System.Text.Json;

namespace ReceiptScanner
{
    public class Program : ReceiptScannerMethods
    {
        public static async Task Main(string[] args)
        {
            string apiUrl = Constants.ApiUrl;

            List<ScannerData>? scannedData;

            try
            {
                using (HttpClient httpClient = new HttpClient()) // Creating an instance of the HttpClient
                {
                    HttpResponseMessage response = await httpClient.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        JsonSerializerOptions options = new JsonSerializerOptions
                        {
                            PropertyNamingPolicy = JsonNamingPolicy.CamelCase // Using this option so that the serializer can recognize and input the data in the correct fields.
                        };

                        string jsonResponse = await response.Content.ReadAsStringAsync(); // Reading the API data as string
                        scannedData = JsonSerializer.Deserialize<List<ScannerData>>(jsonResponse, options); // Converting the API Data into a list of ScannerData objects
                        bool hasInvalidData = CheckForInvalidData(scannedData);

                        if (hasInvalidData)
                        {
                            Console.WriteLine("Some data in the API response is missing or is invalid.");
                            return;
                        }

                    }
                    else
                    {
                        Console.WriteLine($"Unable to get the data. Status code is {response.StatusCode}");
                        return;
                    }

                    var groupedData = GroupByOrigin(scannedData);  // Grouping the data by domestic or imported, ordering the data by domestic first and imported second

                    foreach (var data in groupedData) // Writing the data to the console, Domestic first, its items and then for imported as well
                    {
                        Console.WriteLine($". {CheckOrigin(data)}");
                        var orderedData = OrderItemsAlphabetically(data); // Ordering the data inside the specific group, domestic or imported


                        foreach (var item in orderedData)
                        {
                            string truncatedDescription = TruncateDescription(item); // Getting the description truncated to 10 characters
                            Console.Write($"... {item.Name}");
                            Console.Write($"\n    Price: ${PrintingPriceWithOneDecimal(item)}\n    {truncatedDescription}...");
                            Console.WriteLine($"\n    Weight: {PrintingWeightIfAvailable(item)}");
                        }
                    }

                    foreach (var data in groupedData) // Writing the cost data to the console
                    {
                        string? sum = TotalCostOfProducts(data);
                        Console.WriteLine($"{CheckOrigin(data)} cost: ${sum}");
                    }

                    foreach (var data in groupedData) // Writing the count data to the console
                    {
                        int numberOfItems = TotalNumberOfPurchasedProducts(data);
                        Console.WriteLine($"{CheckOrigin(data)} count: {numberOfItems}");
                    }
                }
            }
            catch(HttpRequestException ex)
            {
                Console.WriteLine($"There was an error with the HTTP request: {ex}");
            }
            catch(JsonException ex)
            {
                Console.WriteLine($"There was a JSON error: {ex}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex}");
            }
        }
    }
}