﻿namespace ReceiptScanner
{
    public class ScannerData
    {
        public string? Name { get; set; }
        public bool? Domestic { get; set; }
        public double? Price { get; set; }
        public int? Weight { get; set; }
        public string? Description { get; set; }
    }
}