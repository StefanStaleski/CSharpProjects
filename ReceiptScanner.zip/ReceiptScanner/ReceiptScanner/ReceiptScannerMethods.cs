﻿namespace ReceiptScanner
{
    public class ReceiptScannerMethods
    {

        /// <summary>
        /// Checks if there is ANY invalid data inside the response of the API and if there is, it will return true.
        /// </summary>
        public static bool CheckForInvalidData(List<ScannerData>? scannedData)
        {
            return scannedData!.Any(data => string.IsNullOrWhiteSpace(data.Name) || string.IsNullOrWhiteSpace(data.Description) || data.Price <= 0 || data.Domestic is null);
        }

        /// <summary>
        /// Groups the provided data depending if it is true or false, placing true first and false second.
        /// </summary>
        public static List<IGrouping<bool, ScannerData>> GroupByOrigin(List<ScannerData>? scannedData)
        {
            return scannedData!.GroupBy(x => x.Domestic.GetValueOrDefault()).OrderByDescending(x => x.Key).ToList();
        }

        /// <summary>
        /// Checks if the data provided is true or false and based on that, it will determine if it is Domestic(true) or Imported(false).
        /// </summary>
        public static string CheckOrigin(IGrouping<bool, ScannerData> data)
        {
            return data.Key ? "Domestic" : "Imported";
        }

        /// <summary>
        /// Orders the items inside the provided data alphabetically.
        /// </summary>
        public static IOrderedEnumerable<ScannerData> OrderItemsAlphabetically(IGrouping<bool, ScannerData> data)
        {
            return data.OrderBy(x => x.Name);
        }

        /// <summary>
        /// Returns the price with one decimal.
        /// </summary>
        public static string? PrintingPriceWithOneDecimal(ScannerData item) => item.Price?.ToString("F1");

        /// <summary>
        /// It will check if the variable Weight contains data, if it does it will print it and if it does not, it will print "N/A".
        /// </summary>
        public static string PrintingWeightIfAvailable(ScannerData? item)
        {
            if (item!.Weight == null)
            {
                return "N/A";
            }
            else
            {
                return item.Weight.Value.ToString() + "g";
            }
        }

        /// <summary>
        /// Provides the total cost of the provided data.
        /// </summary>
        public static string? TotalCostOfProducts(IGrouping<bool, ScannerData> data) => data.Sum(x => x.Price)?.ToString("F1");

        /// <summary>
        /// Provides the total number of items inside the provided data.
        /// </summary>
        public static int TotalNumberOfPurchasedProducts(IGrouping<bool, ScannerData> data)
        {
            return data.Count();
        }

        /// <summary>
        /// Truncates the description to 10 characters if longer than 10.
        /// </summary>
        public static string TruncateDescription(ScannerData? item)
        {
            return item!.Description!.Substring(0, 10);
        }
    }
}