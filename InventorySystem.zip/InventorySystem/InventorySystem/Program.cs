﻿using System.Globalization;
using System.Runtime.InteropServices;

namespace InventorySystem
{
    public class Inventory
    {
        public string Name { get; set; }
        public string Category { get; set; }
        public int Quantity { get; set; }
        public double Price { get; set; }

        public Inventory(string name, string category, int quantity, double price)
        {
            Name = name;
            Category = category;
            Quantity = quantity;
            Price = price;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                List<Inventory> inventory = new List<Inventory>
                {
                    new Inventory ("Item1", "CategoryA", 10, 5.99),
                    new Inventory ("Item2", "CategoryB", 15, 7.50),
                    new Inventory ("Item3", "CategoryA", 20, 9.99),
                    new Inventory ("Item4", "CategoryC", 8, 12.25),
                    new Inventory ("Item5", "CategoryB", 12, 6.75)
                };

                bool userIsFinished = false;

                while (!userIsFinished)
                {
                    UserInterface();
                    var userInput = Console.ReadLine();

                    switch (userInput)
                    {
                        case "1":
                            ViewAllItemsInInventory(inventory); break;
                        case "2":
                            CreateItem(inventory); break;
                        case "3":
                            Console.WriteLine("Provide the name of the item that you would like to remove.");
                            var nameOfItemToBeRemoved = Console.ReadLine();
                            var wasItemRemoved = RemoveItemFromInventory(inventory, nameOfItemToBeRemoved);
                            Console.WriteLine($"\n{wasItemRemoved}"); break;
                        case "4":
                            Console.WriteLine("Provide me the search criteria:");
                            var searchQuery = Console.ReadLine();
                            SearchItemsInInventory(inventory, searchQuery); break;
                        case "5":
                            Console.WriteLine("Provide me the name of the item that you would like to update:");
                            var nameOfItemToBeUpdated = Console.ReadLine();
                            Console.WriteLine("Provide me the updated quantity:");
                            var quantityOfItemToBeUpdated = int.Parse(Console.ReadLine());
                            UpdateQuantityOfItem(inventory, nameOfItemToBeUpdated, quantityOfItemToBeUpdated); break;
                        case "6":
                            Console.WriteLine("Provide me the name of the item that you wish to see:");
                            var itemName = Console.ReadLine();
                            ViewCertainItem(inventory, itemName); break;
                        case "7":
                            userIsFinished = true;
                            ViewAllItemsInInventory(inventory);
                            Console.WriteLine("Thank you for using the inventory system, the system will now close. Have a nice day!");
                            return;
                    }
                }
            }

            catch(FormatException ex)
            {
                Console.WriteLine($"There was a FormatException: {ex.Message}");
            }
        }

        private static void ViewCertainItem(List<Inventory> inventory, string? itemName)
        {
            var item = inventory.FirstOrDefault(x => x.Name == itemName);

            if (item == null)
            {
                Console.WriteLine("Item with that name was not found.");
                return;
            }

            PrintItem(item);
        }

        private static void CreateItem(List<Inventory> inventory)
        {
            Console.WriteLine("Input the item name:");
            var itemName = Console.ReadLine();
            Console.WriteLine("Input the item category:");
            var itemCategory = Console.ReadLine();
            Console.WriteLine("Input the item quantity:");
            var itemQuantity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Input the item price");
            var itemPrice = Convert.ToDouble(Console.ReadLine(), new NumberFormatInfo { NumberDecimalSeparator = "." });

            bool isInputValid = CheckUserInput(itemName, itemCategory, itemQuantity, itemPrice);

            if (!isInputValid)
            {
                Console.WriteLine("You have inserted an invalid input.\n");
                return;
            }

            AddNewItemToInventory(inventory, new Inventory(itemName, itemCategory, itemQuantity, itemPrice));
        }

        private static bool CheckUserInput(string itemName, string itemCategory, int itemQuantity, double itemPrice)
        {
            if (string.IsNullOrWhiteSpace(itemName) || string.IsNullOrWhiteSpace(itemCategory) || itemQuantity <= 0 || itemPrice <= 0)
            {
                return false;
            }

            return true;
        }

        private static void UserInterface()
        {
            Console.WriteLine("Choose one of the following:");
            Console.WriteLine("1. View all the items in the inventory.");
            Console.WriteLine("2. Add a new item to the inventory.");
            Console.WriteLine("3. Remove an item from the inventory.");
            Console.WriteLine("4. Search for an item inside the inventory.");
            Console.WriteLine("5. Update quantity of an item inside the inventory.");
            Console.WriteLine("6. View a certain item in the inventory.");
            Console.WriteLine("7. Exit.");
        }

        private static void UpdateQuantityOfItem(List<Inventory> inventory, string itemName, int updatedQuantity)
        {
            if (!inventory.Any(x => x.Name == itemName))
            {
                Console.WriteLine("Item was not found.\n");
                return;
            }

            inventory.FirstOrDefault(x => x.Name == itemName).Quantity = updatedQuantity;
            Console.WriteLine("Item updated.\n");
        }

        private static void SearchItemsInInventory(List<Inventory> inventory, string searchQuery)
        {
            inventory = inventory.Where(x => x.Name.Contains(searchQuery) || x.Category.Contains(searchQuery)).ToList();

            if (inventory.Count == 0)
            {
                Console.WriteLine("No items were found with that search criteria.\n");
                return;
            }

            Console.WriteLine("Items found with that search criteria:");
            ViewAllItemsInInventory(inventory);
        }

        private static string RemoveItemFromInventory(List<Inventory> inventory, string v)
        {
            var itemToBeRemoved = inventory.FirstOrDefault(x => x.Name.Contains(v) || x.Category.Contains(v));

            if (itemToBeRemoved == null)
            {
                return "Item was not found.\n";
            }

            inventory.Remove(itemToBeRemoved);
            return "Item was removed.\n";
        }

        private static void AddNewItemToInventory(List<Inventory> inventory, Inventory item)
        {
            inventory.Add(item);
            Console.WriteLine("Item was added to the inventory.\n");
        }

        private static void ViewAllItemsInInventory(List<Inventory> inventory)
        {
            foreach (var item in inventory)
            {
                PrintItem(item);
            }
        }

        private static void PrintItem(Inventory item)
        {
            Console.WriteLine($"Item name: {item.Name}, Item category: {item.Category}, Item quantity: {item.Quantity}, Item Price: {item.Price}.\n");
        }
    }
}