﻿using System.Net;

namespace LibraryManagement
{
    class Program
    {
        public class Library
        {
            public List<Book> Books { get; set; } = new List<Book>();
        }
        public enum Genre
        {
            Fiction, ScienceFiction, NonFiction, Mystery, Romance
        }
        public class Book
        {
            public string Title { get; set; }
            public Author Author { get; set; }
            public Genre BookGenre { get; set; }
        }
        public class Author
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
        }
        static void Main(string[] args)
        {
            var library = new Library();

            Book book1 = new Book
            {
                Title = "The Catcher in the Rye",
                Author = new Author { FirstName = "J.D.", LastName = "Salinger" },
                BookGenre = Genre.Fiction
            };
            AddBookToLibrary(library, book1);
            Book book2 = new Book
            {
                Title = "To Kill a Mockingbird",
                Author = new Author { FirstName = "Harper", LastName = "Lee" },
                BookGenre = Genre.Fiction
            };
            AddBookToLibrary(library, book2);
            Book book3 = new Book
            {
                Title = "1984",
                Author = new Author { FirstName = "George", LastName = "Orwell" },
                BookGenre = Genre.ScienceFiction
            };
            AddBookToLibrary(library, book3);

            Console.WriteLine("Select an option:");
            Console.WriteLine("1. Add a book");
            Console.WriteLine("2. Remove a book");
            Console.WriteLine("3. View all books");
            Console.WriteLine("4. View books by author");
            Console.WriteLine("5. View books by genre");
            Console.WriteLine("6. View count of books by genre");
            Console.WriteLine("7. View count of books by author");
            Console.WriteLine("8. Exit");
            var userInput = Console.ReadLine();

            switch (userInput)
            {
                case "1":
                    Console.WriteLine("Give me the title of the book:");
                    var bookTitle = Console.ReadLine();
                    Console.WriteLine("Give me the first name of the author of the book:");
                    var authorFirstName = Console.ReadLine();
                    Console.WriteLine("Give me the last name of the author of the book:");
                    var authorLastName = Console.ReadLine();
                    Console.WriteLine("Choose the genre of the book:");
                    Console.WriteLine("1. Fiction");
                    Console.WriteLine("2. ScienceFiction");
                    Console.WriteLine("3. NonFiction");
                    Console.WriteLine("4. Mystery");
                    Console.WriteLine("5. Romance");
                    var genreInput = Console.ReadLine();
                    switch (genreInput)
                    {
                        case "1":
                            AddBookToLibrary(library, new Book
                            {
                                Title = bookTitle,
                                Author = new Author { FirstName = authorFirstName, LastName = authorLastName },
                                BookGenre = Genre.Fiction
                            });
                            break;
                        case "2":
                            AddBookToLibrary(library, new Book
                            {
                                Title = bookTitle,
                                Author = new Author { FirstName = authorFirstName, LastName = authorLastName },
                                BookGenre = Genre.ScienceFiction
                            });
                            break;
                        case "3":
                            AddBookToLibrary(library, new Book
                            {
                                Title = bookTitle,
                                Author = new Author { FirstName = authorFirstName, LastName = authorLastName },
                                BookGenre = Genre.NonFiction
                            });
                            break;
                        case "4":
                            AddBookToLibrary(library, new Book
                            {
                                Title = bookTitle,
                                Author = new Author { FirstName = authorFirstName, LastName = authorLastName },
                                BookGenre = Genre.Mystery
                            });
                            break;
                        case "5":
                            AddBookToLibrary(library, new Book
                            {
                                Title = bookTitle,
                                Author = new Author { FirstName = authorFirstName, LastName = authorLastName },
                                BookGenre = Genre.Romance
                            });
                            break;
                        default:
                            Console.WriteLine("Invalid input. Please enter a valid number.");
                            return;
                    }
                    ViewAllBooksInLibrary(library);
                    break;
                case "2":
                    RemoveBookFromLibrary(library, book1);
                    break;
                case "3":
                    ViewAllBooksInLibrary(library);
                    break;
                case "4":
                    ViewBooksByAuthor(library, "Harper Lee");
                    break;
                case "5":
                    ViewBooksByGenre(library, Genre.Fiction);
                    break;
                case "6":
                    ViewCountOfBooksForEachGenre(library);
                    break;
                case "7":
                    ViewCountOfBooksForEachAuthor(library);
                    break;
                case "8":
                    break;
                default:
                    Console.WriteLine("Invalid input. Please enter a valid number.");
                    break;
            }
        }

        public static void AddBookToLibrary(Library library, Book book)
        {
            if (library == null)
            {
                library.Books = new List<Book>();
            }
            library.Books.Add(book);
        }
        public static void RemoveBookFromLibrary(Library library, Book book)
        {
            library.Books.Remove(book);
        }

        public static void ViewAllBooksInLibrary(Library library)
        {
            foreach (var book in library.Books)
            {
                Console.Write($"Title: {book.Title} ");
                Console.Write($"Author: {book.Author.FirstName} {book.Author.LastName} ");
                Console.WriteLine($"Genre: {book.BookGenre}");
            }
        }
        public static void ViewBooksByAuthor(Library library, string userAuthorInput)
        {
            library.Books = library.Books.Where(b => b.Author.FirstName == userAuthorInput || 
            b.Author.LastName == userAuthorInput || b.Author.FirstName + " " + b.Author.LastName == userAuthorInput).ToList();
            ViewAllBooksInLibrary(library);
        }
        public static void ViewBooksByGenre(Library library, Genre genre)
        {
            library.Books = library.Books.Where(b => b.BookGenre == genre).ToList();
            ViewAllBooksInLibrary(library);
        }

        public static void ViewCountOfBooksForEachGenre(Library library)
        {
            var booksByGenre = library.Books.GroupBy(b => b.BookGenre).ToList();
            foreach (var book in booksByGenre)
            {
                Console.WriteLine($"Number of {book.Key} books: {book.Count()}");
            }
        }

        public static void ViewCountOfBooksForEachAuthor(Library library)
        {
            var booksByAuthor = library.Books.GroupBy(b => b.Author.FirstName + " " + b.Author.LastName).ToList();
            foreach (var book in booksByAuthor)
            {
                Console.WriteLine($"Author: {book.Key}, number of books: {book.Count()}");
            }
        }
    }
}